import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from io import StringIO
import os

# Page config
st.set_page_config(page_title="Crop Production Analysis & Yield Prediction", layout="wide")

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #ff7f0e;
        margin-top: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        text-align: center;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.5rem;
    }
    .stTabs [data-baseweb="tab"] {
        height: 3rem;
    }
</style>
""", unsafe_allow_html=True)

# Sidebar for navigation and info
with st.sidebar:
    st.header("🌾 Crop App")
    st.info("Navigate using the tabs below for analysis, visualizations, monitoring, and predictions.")
    st.markdown("---")
    st.subheader("Quick Stats")
    if 'df' in locals():
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Records", len(df))
        with col2:
            st.metric("Unique Crops", df['Crop'].nunique())
        with col3:
            st.metric("Unique States", df['State_Name'].nunique())
        with col4:
            st.metric("Avg Yield", f"{df['Yield'].mean():.2f}")
    st.markdown("---")
    st.subheader("About")
    st.write("Enhanced Crop Production Dashboard with Monitoring & ML Predictions")

# Original code integration and enhancements

# List files (from original code)
# for dirname, _, filenames in os.walk('/kaggle/input'):
#     for filename in filenames:
#         print(os.path.join(dirname, filename))

# Load the dataset - In production, replace with actual path or upload
@st.cache_data
def load_data():
    # For demo, using the provided path; in real use, use st.file_uploader
    try:
        df = pd.read_csv("/kaggle/input/crop-production-in-india/crop_production.csv")
        return df
    except:
        # Fallback: create sample data if path not available
        sample_data = {
            'State_Name': np.random.choice(['Andhra Pradesh', 'Karnataka', 'Tamil Nadu'], 100),
            'District_Name': np.random.choice(['District1', 'District2', 'District3'], 100),
            'Crop_Year': np.random.randint(2010, 2020, 100),
            'Season': np.random.choice(['Kharif', 'Rabi'], 100),
            'Crop': np.random.choice(['Rice', 'Wheat', 'Maize'], 100),
            'Area': np.random.uniform(100, 1000, 100),
            'Production': np.random.uniform(200, 2000, 100)
        }
        return pd.DataFrame(sample_data)

df = load_data()

# Data cleaning
df.dropna(subset=["Production"], axis=0, inplace=True)

# Add synthetic monitoring data for new features
np.random.seed(42)
n = len(df)
df['Soil_Moisture'] = np.random.uniform(20, 60, n)  # %
df['Temperature'] = np.random.uniform(15, 35, n)    # Celsius
df['Humidity'] = np.random.uniform(40, 80, n)       # %
df['pH'] = np.random.uniform(5, 8, n)
df['Nutrient_N'] = np.random.uniform(50, 150, n)    # kg/ha
df['Nutrient_P'] = np.random.uniform(20, 60, n)     # kg/ha
df['Nutrient_K'] = np.random.uniform(50, 200, n)    # kg/ha
df['Pest_Level'] = np.random.randint(0, 5, n)       # Scale 0-4
df['Disease_Level'] = np.random.randint(0, 5, n)    # Scale 0-4
df['Rainfall'] = np.random.uniform(500, 2000, n)    # mm/year for weather conditions

# Calculate Yield (Production per Area)
df['Yield'] = df['Production'] / df['Area']
df['Yield'].replace([np.inf, -np.inf], np.nan, inplace=True)
df.dropna(subset=['Yield'], inplace=True)

# Crop categorization function (fixed to use lists and if-elif for efficiency)
def cat_crop(cc):
    cereals = ['Rice','Maize','Wheat','Barley','Varagu','Other Cereals & Millets','Ragi','Small millets','Bajra','Jowar', 'Paddy']
    pulses = ['Moong','Urad','Arhar/Tur','Peas & beans','Masoor','Other Kharif pulses','other misc. pulses','Ricebean (nagadal)',
              'Rajmash Kholar','Lentil','Samai','Blackgram','Korra','Cowpea(Lobia)','Other  Rabi pulses','Other Kharif pulses',
              'Peas & beans (Pulses)','Pulses total','Gram']
    fruits = ['Peach','Apple','Litchi','Pear','Plums','Ber','Sapota','Lemon','Pome Granet','Other Citrus Fruit','Water Melon',
              'Jack Fruit','Grapes','Pineapple','Orange','Pome Fruit','Citrus Fruit','Other Fresh Fruits','Mango','Papaya','Coconut','Banana']
    beans = ['Bean','Lab-Lab','Moth','Guar seed','Tapioca','Soyabean','Horse-gram']
    vegetables = ['Turnip','Peas','Beet Root','Carrot','Yam','Ribed Guard','Ash Gourd ','Pump Kin','Redish','Snak Guard','Bottle Gourd',
                  'Bitter Gourd','Cucumber','Drum Stick','Cauliflower','Beans & Mutter(Vegetable)','Cabbage','Bhindi','Tomato',
                  'Brinjal','Khesari','Sweet potato','Potato','Onion','Colocosia']
    species = ['Perilla','Ginger','Cardamom','Black pepper','Dry ginger','Garlic','Coriander','Turmeric','Dry chillies','Cond-spcs other']
    fibres = ['other fibres','Kapas','Jute & mesta','Jute','Mesta','Cotton(lint)']
    nuts = ['Arcanut (Processed)','Atcanut (Raw)','Cashewnut Processed','Cashewnut Raw','Cashewnut','Arecanut','Groundnut']
    natural = ['Rubber']
    coffee = ['Coffee']
    tea = ['Tea']
    total_foodgrain = ['Total foodgrain']
    oilseeds = ['other oilseeds','Safflower','Niger seed','Castor seed','Linseed','Sunflower','Rapeseed &Mustard','Sesamum','Oilseeds total']
    sugarcane = ['Sugarcane']
    tobacco = ['Tobacco']
    fertile = ['Sannhamp']
    other = ['Jobster', 'other misc. pulses', 'Other']

    if cc in cereals:
        return 'Cereal'
    elif cc in pulses:
        return 'Pulses'
    elif cc in fruits:
        return 'Fruits'
    elif cc in beans:
        return 'Beans'
    elif cc in vegetables:
        return 'Vegetables'
    elif cc in species:
        return 'Species'
    elif cc in fibres:
        return 'Fibres'
    elif cc in nuts:
        return 'Nuts'
    elif cc in natural:
        return 'Natural Polymer'
    elif cc in coffee:
        return 'Coffee'
    elif cc in tea:
        return 'Tea'
    elif cc in total_foodgrain:
        return 'Total foodgrain'
    elif cc in oilseeds:
        return 'Oilseeds'
    elif cc in sugarcane:
        return 'Sugarcane'
    elif cc in tobacco:
        return 'Commercial'
    elif cc in fertile:
        return 'Fertile Plant'
    elif cc in other:
        return 'Other'
    else:
        return 'Other'

df['cat_crop'] = df['Crop'].apply(cat_crop)

# Prepare data for ML model
@st.cache_data
def prepare_model():
    le_state = LabelEncoder()
    df_temp = df.copy()
    df_temp['State_Name_enc'] = le_state.fit_transform(df_temp['State_Name'])

    le_district = LabelEncoder()
    df_temp['District_Name_enc'] = le_district.fit_transform(df_temp['District_Name'])

    le_season = LabelEncoder()
    df_temp['Season_enc'] = le_season.fit_transform(df_temp['Season'])

    le_crop = LabelEncoder()
    df_temp['Crop_enc'] = le_crop.fit_transform(df_temp['Crop'])

    # Features for prediction (including new monitoring features)
    features = ['State_Name_enc', 'District_Name_enc', 'Crop_Year', 'Season_enc', 'Crop_enc', 'Area',
                'Soil_Moisture', 'Temperature', 'Humidity', 'pH', 'Nutrient_N', 'Nutrient_P', 'Nutrient_K',
                'Pest_Level', 'Disease_Level', 'Rainfall']

    X = df_temp[features]
    y = df_temp['Yield']

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    return model, le_state, le_district, le_season, le_crop, features

model, le_state, le_district, le_season, le_crop, features = prepare_model()

# Main Header
st.markdown('<h1 class="main-header">🌾 Crop Production Analysis, Monitoring, and Yield Prediction</h1>', unsafe_allow_html=True)

# Display the image from original code
st.image('https://bloximages.chicago2.vip.townnews.com/agupdate.com/content/tncms/assets/v3/editorial/8/2a/82a2c290-b87f-11e9-b6b7-f302b3f72951/5d49d3961bef2.image.jpg?resize=750%2C422.jpg', 
         caption="Agricultural Landscape - India Crop Production")

# Tabs for organization
tab1, tab2, tab3, tab4 = st.tabs(["📊 Data Overview", "📈 Visualizations", "🔍 Monitoring Insights", "🔮 Yield Prediction"])

with tab1:
    st.markdown('<h2 class="sub-header">Data Overview</h2>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Dataset Preview")
        st.dataframe(df.head(10), use_container_width=True)
    
    with col2:
        st.subheader("Dataset Info")
        buffer = StringIO()
        df.info(buf=buffer)
        st.text(buffer.getvalue())
        
        st.subheader("Descriptive Statistics")
        st.dataframe(df.describe(), use_container_width=True)
    
    col3, col4 = st.columns(2)
    with col3:
        st.subheader("Unique States")
        st.write(df["State_Name"].unique())
    
    with col4:
        st.subheader("Unique Districts Count")
        st.metric("Number of Districts", df.District_Name.nunique())

with tab2:
    st.markdown('<h2 class="sub-header">Visualizations</h2>', unsafe_allow_html=True)
    
    # Boxplots
    st.subheader("Boxplots - Production Distribution")
    col1, col2, col3 = st.columns(3)
    with col1:
        fig1, ax1 = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x="Season", y="Production", ax=ax1)
        st.pyplot(fig1)
    
    with col2:
        fig2, ax2 = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x="cat_crop", y="Production", ax=ax2)
        plt.xticks(rotation=45)
        st.pyplot(fig2)
    
    with col3:
        fig3, ax3 = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x=df["Crop_Year"] % 5, y="Production", ax=ax3)  # Grouped by year mod 5 for demo
        st.pyplot(fig3)
    
    # Bar plots
    st.subheader("Production Trends")
    col4, col5 = st.columns(2)
    with col4:
        fig4, ax4 = plt.subplots(figsize=(10, 5))
        df.groupby("Crop_Year")["Production"].agg("sum").plot.bar(ax=ax4, color='skyblue')
        plt.title("Total Production by Year")
        st.pyplot(fig4)
    
    with col5:
        fig5, ax5 = plt.subplots(figsize=(10, 5))
        top_crops = df.groupby("Crop")["Production"].agg("count").nlargest(10)
        top_crops.plot.bar(ax=ax5, color='lightgreen')
        plt.title("Top Crops by Count")
        plt.xticks(rotation=45)
        st.pyplot(fig5)
    
    # Pie chart
    st.subheader("Crop Categories Distribution")
    fig6, ax6 = plt.subplots(figsize=(8, 8))
    df1 = df["cat_crop"].value_counts()
    df1.plot.pie(autopct="%1.1f%%", pctdistance=0.8, ax=ax6, colors=sns.color_palette('Set2'))
    plt.ylabel('')
    st.pyplot(fig6)
    
    # Stacked bar
    st.subheader("Crop Categories by State (Top 10 States)")
    fig7, ax7 = plt.subplots(figsize=(14, 6))
    top_states = df['State_Name'].value_counts().head(10).index
    df_filtered = df[df['State_Name'].isin(top_states)]
    df2 = pd.crosstab(df_filtered['State_Name'], df_filtered['cat_crop'])
    df2.plot(kind='bar', stacked=True, ax=ax7, colormap='tab20')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.xticks(rotation=45)
    st.pyplot(fig7)
    
    # Heatmap
    st.subheader("Correlation Heatmap (Numeric Features)")
    numeric_df = df.select_dtypes(include=[np.number])
    fig8, ax8 = plt.subplots(figsize=(12, 10))
    sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm', center=0, ax=ax8, fmt='.2f')
    st.pyplot(fig8)

with tab3:
    st.markdown('<h2 class="sub-header">Monitoring Insights</h2>', unsafe_allow_html=True)
    st.write("Interactive visualizations for key monitoring parameters: Soil Moisture, Temperature, Humidity, pH, Nutrients, Pests, Diseases, and Weather.")
    
    # Scatterplot for monitoring
    st.subheader("Crop Categories by State and Season")
    fig9, ax9 = plt.subplots(figsize=(20, 8))
    sns.scatterplot(data=df, x="State_Name", y="cat_crop", hue="Season", style="Season", ax=ax9, s=50)
    plt.xticks(rotation=90)
    plt.title("Distribution of Crop Categories Across States and Seasons")
    st.pyplot(fig9)
    
    # Monitoring specific plots
    monitoring_cols = st.columns(3)
    with monitoring_cols[0]:
        st.subheader("Soil Moisture by Crop Category")
        fig10, ax10 = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x="cat_crop", y="Soil_Moisture", ax=ax10)
        plt.xticks(rotation=45)
        st.pyplot(fig10)
    
    with monitoring_cols[1]:
        st.subheader("Temperature by Season")
        fig11, ax11 = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x="Season", y="Temperature", ax=ax11)
        st.pyplot(fig11)
    
    with monitoring_cols[2]:
        st.subheader("Humidity by Crop Category")
        fig12, ax12 = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x="cat_crop", y="Humidity", ax=ax12)
        plt.xticks(rotation=45)
        st.pyplot(fig12)
    
    pH_col, nutrient_col = st.columns(2)
    with pH_col:
        st.subheader("pH Levels by Top Crops")
        top_crops_ph = df[df['Crop'].isin(df['Crop'].value_counts().head(5).index)]
        fig13, ax13 = plt.subplots(figsize=(10, 5))
        sns.boxplot(data=top_crops_ph, x="Crop", y="pH", ax=ax13)
        plt.xticks(rotation=45)
        st.pyplot(fig13)
    
    with nutrient_col:
        st.subheader("Nutrient Levels Distribution")
        fig14, ax14 = plt.subplots(figsize=(10, 5))
        sns.histplot(data=df, x="Nutrient_N", kde=True, color="blue", label="N", alpha=0.5, ax=ax14)
        sns.histplot(data=df, x="Nutrient_P", kde=True, color="green", label="P", alpha=0.5, ax=ax14)
        sns.histplot(data=df, x="Nutrient_K", kde=True, color="red", label="K", alpha=0.5, ax=ax14)
        ax14.legend()
        plt.title("NPK Nutrient Distributions")
        st.pyplot(fig14)
    
    pest_disease_col = st.columns(2)
    with pest_disease_col[0]:
        st.subheader("Pest Levels Count")
        fig15, ax15 = plt.subplots(figsize=(8, 5))
        sns.countplot(data=df, x="Pest_Level", ax=ax15, palette='viridis')
        st.pyplot(fig15)
    
    with pest_disease_col[1]:
        st.subheader("Disease Levels Count")
        fig16, ax16 = plt.subplots(figsize=(8, 5))
        sns.countplot(data=df, x="Disease_Level", ax=ax16, palette='plasma')
        st.pyplot(fig16)
    
    st.subheader("Weather Conditions - Avg Rainfall by Year")
    fig17, ax17 = plt.subplots(figsize=(12, 6))
    df.groupby("Crop_Year")["Rainfall"].mean().plot.bar(ax=ax17, color='lightblue', alpha=0.7)
    plt.title("Average Rainfall by Crop Year")
    plt.xticks(rotation=45)
    st.pyplot(fig17)

with tab4:
    st.markdown('<h2 class="sub-header">Yield Prediction and Forecasting</h2>', unsafe_allow_html=True)
    st.write("Enter monitoring parameters below to get a data-driven yield prediction using Random Forest model.")
    
    # User inputs in columns for better layout
    input_col1, input_col2 = st.columns(2)
    
    with input_col1:
        state = st.selectbox("🌍 State Name", options=sorted(df["State_Name"].unique()))
        district_options = sorted(df[df["State_Name"] == state]["District_Name"].unique())
        district = st.selectbox("🏘️ District Name", options=district_options)
        crop_year = st.number_input("📅 Crop Year", min_value=1990, max_value=2050, value=2025)
        season = st.selectbox("☀️ Season", options=sorted(df["Season"].unique()))
        crop = st.selectbox("🌱 Crop", options=sorted(df["Crop"].unique()))
        area = st.number_input("📏 Area (hectares)", min_value=0.1, value=10.0, step=0.5)
    
    with input_col2:
        soil_moisture = st.slider("💧 Soil Moisture (%)", 0.0, 100.0, 40.0)
        temperature = st.slider("🌡️ Temperature (°C)", 0.0, 50.0, 25.0)
        humidity = st.slider("💨 Humidity (%)", 0.0, 100.0, 60.0)
        ph = st.slider("🧪 Soil pH", 0.0, 14.0, 6.5)
        rainfall = st.number_input("🌧️ Annual Rainfall (mm)", 0.0, 3000.0, 1000.0)
    
    # Nutrients and Risks in expander for space
    with st.expander("🍎 Advanced Inputs: Nutrients & Risks", expanded=False):
        nutrient_col1, nutrient_col2, nutrient_col3 = st.columns(3)
        with nutrient_col1:
            nutrient_n = st.number_input("Nitrogen (kg/ha)", 0.0, 300.0, 100.0)
        with nutrient_col2:
            nutrient_p = st.number_input("Phosphorus (kg/ha)", 0.0, 100.0, 40.0)
        with nutrient_col3:
            nutrient_k = st.number_input("Potassium (kg/ha)", 0.0, 300.0, 100.0)
        
        risk_col1, risk_col2 = st.columns(2)
        with risk_col1:
            pest_level = st.slider("🐛 Pest Level (0-4)", 0, 4, 1)
        with risk_col2:
            disease_level = st.slider("🦠 Disease Level (0-4)", 0, 4, 1)
    
    # Prediction button
    if st.button("🚀 Predict Yield", type="primary", use_container_width=True):
        try:
            # Prepare input data
            input_data = {
                'State_Name': state,
                'District_Name': district,
                'Crop_Year': crop_year,
                'Season': season,
                'Crop': crop,
                'Area': area,
                'Soil_Moisture': soil_moisture,
                'Temperature': temperature,
                'Humidity': humidity,
                'pH': ph,
                'Nutrient_N': nutrient_n,
                'Nutrient_P': nutrient_p,
                'Nutrient_K': nutrient_k,
                'Pest_Level': pest_level,
                'Disease_Level': disease_level,
                'Rainfall': rainfall
            }
            input_df = pd.DataFrame([input_data])
            
            # Encode inputs (handle new categories gracefully)
            input_df['State_Name_enc'] = le_state.transform([state])[0] if state in le_state.classes_ else le_state.transform(le_state.classes_)[0]  # Fallback to first
            input_df['District_Name_enc'] = le_district.transform([district])[0] if district in le_district.classes_ else le_district.transform(le_district.classes_)[0]
            input_df['Season_enc'] = le_season.transform([season])[0]
            input_df['Crop_enc'] = le_crop.transform([crop])[0]
            
            # Select features
            input_X = input_df[features].fillna(0)  # Fill NaN if any
            
            # Predict
            predicted_yield = model.predict(input_X)[0]
            predicted_production = predicted_yield * area
            
            # Display results in metric cards
            col_pred1, col_pred2, col_pred3 = st.columns(3)
            with col_pred1:
                st.markdown('<div class="metric-card"><h3>🌾 Predicted Yield</h3><h1>{:.2f} kg/ha</h1></div>'.format(predicted_yield), unsafe_allow_html=True)
            with col_pred2:
                st.markdown('<div class="metric-card"><h3>📈 Total Production</h3><h1>{:.2f} kg</h1></div>'.format(predicted_production), unsafe_allow_html=True)
            with col_pred3:
                confidence = np.std(model.predict(input_X))  # Simple confidence proxy
                st.markdown('<div class="metric-card"><h3>🎯 Confidence</h3><h1>{:.1f}%</h1></div>'.format((1 - confidence / predicted_yield) * 100), unsafe_allow_html=True)
            
            st.success("✅ Prediction completed! Adjust inputs for different scenarios.")
            
            # Feature importance (top 5)
            st.subheader("Key Influencing Factors")
            importance_df = pd.DataFrame({
                'Feature': features,
                'Importance': model.feature_importances_
            }).sort_values('Importance', ascending=False).head(5)
            fig_imp, ax_imp = plt.subplots(figsize=(10, 4))
            sns.barplot(data=importance_df, x='Importance', y='Feature', ax=ax_imp, palette='viridis')
            st.pyplot(fig_imp)
            
        except Exception as e:
            st.error(f"❌ Prediction error: {str(e)}. Please check inputs.")

# Footer
st.markdown("---")
st.markdown("<p style='text-align: center; color: grey;'>Built with ❤️ using Streamlit | Data from Crop Production in India Dataset</p>", unsafe_allow_html=True)